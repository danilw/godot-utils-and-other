
Uniforms:(material_override sine_effect)

iTime - time value (must be minimum in range ray_animation_time (loop by its value))
can be (GDScript) iTime+=delta or iTime=fmod(iTime+delta,ray_animation_time)



transform_face_camera - if true transfrom rotated to camera
transform_rotate - animate rotations
glow_none - if true no texture_fake_glow
glow_v1 - if true fake_glow v1
glow_v2 - if true fake_glow v2

fade_value (0-1) - color and alpha multilyer, to fade particles
ray_animation_time - animation time loop
start_radius - radius shift
base_color - background particle color
shine_color - shine particle color

base_texture -tx1024.png main texture
base_texture2 -tx1024_t2.png fake_glow

textures form can be changed, but texture size not full quad, it limited by mesh (mesh has ~1.5x size of tx1024.png)
